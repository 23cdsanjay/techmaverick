document.querySelectorAll('.closebtn').forEach(button => {
    button.addEventListener('click', function () {
        const alertBox = this.parentElement;
        alertBox.style.opacity = "0";
        setTimeout(() => {
            alertBox.style.display = 'none';
        }, 300);
    });
});

function createWeatherAlert(type, title, message) {
    const alertBox = document.createElement('div');
    alertBox.classList.add('alert-box', type);
    alertBox.innerHTML = `
        <span class="icon animate-icon">${getWeatherIconForType(type)}</span>
        <strong>${title}</strong>
        <p>${message}</p>
        <span class="closebtn">&times;</span>
    `;
    document.querySelector('.alert-container').appendChild(alertBox);
    alertBox.querySelector('.closebtn').addEventListener('click', function () {
        alertBox.style.opacity = "0";
        setTimeout(() => { alertBox.style.display = 'none'; }, 300);
    });
}

function getWeatherIconForType(type) {
    switch (type) {
        case 'info': return '🌧️';
        case 'success': return '☀️';
        case 'warning': return '⚠️';
        case 'danger': return '🌪️';
        default: return '';
    }
}

//

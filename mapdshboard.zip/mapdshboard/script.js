let map;
let geocoder;

function initMap() {
    // Initialize Google Map centered on a default location (Delhi, India)
    map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 28.6139, lng: 77.2090 },
        zoom: 10,
    });

    // Initialize geocoder for address lookup
    geocoder = new google.maps.Geocoder();
}

function geocodeAddress() {
    const address = document.getElementById("city-input").value;
    geocoder.geocode({ address: address }, (results, status) => {
        if (status === "OK") {
            map.setCenter(results[0].geometry.location);
            new google.maps.Marker({
                map: map,
                position: results[0].geometry.location,
            });
        } else {
            alert("Geocode was not successful for the following reason: " + status);
        }
    });
}

// Initialize the map when the window loads
window.onload = initMap;

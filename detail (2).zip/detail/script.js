document.addEventListener('DOMContentLoaded', () => {
    const locationInput = document.getElementById('location-input');
    const cityName = document.getElementById('city-name');
    const condition = document.getElementById('condition');
    const temperature = document.getElementById('temperature');
    const dateTime = document.getElementById('date-time');
    const humidity = document.getElementById('humidity');
    const windSpeed = document.getElementById('wind-speed');
    const precipitation = document.getElementById('precipitation');
    const weatherAlert = document.getElementById('weather-alert');

    // Function to update date and time dynamically
    function updateDateTime() {
        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        dateTime.textContent = now.toLocaleDateString('en-US', options);
    }

    // Call updateDateTime function on load
    updateDateTime();

    // Set interval to update time every minute
    setInterval(updateDateTime, 60000);

    // Function to fetch weather data from API
    async function fetchWeatherData(location) {
        const apiKey = 'your_api_key_here';
        const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${location}&units=metric&appid=${apiKey}`;

        try {
            const response = await fetch(apiUrl);
            const data = await response.json();

            // Update the UI with fetched data
            cityName.textContent = `${data.name}, ${data.sys.country}`;
            condition.textContent = data.weather[0].description;
            temperature.textContent = `${Math.round(data.main.temp)}°C`;
            humidity.textContent = `${data.main.humidity}%`;
            windSpeed.textContent = `${Math.round(data.wind.speed)} km/h`;
            precipitation.textContent = `${data.clouds.all}%`;
            
            // Check if there's a weather alert (e.g., storm)
            if (data.weather[0].main.toLowerCase().includes('storm')) {
                weatherAlert.style.display = 'block';
            } else {
                weatherAlert.style.display = 'none';
            }

        } catch (error) {
            console.error("Error fetching weather data:", error);
        }
    }

    // Event listener for location input
    locationInput.addEventListener('change', () => {
        const location = locationInput.value;
        fetchWeatherData(location);
    });

    // Fetch initial weather data for default location (e.g., Berlin)
    fetchWeatherData('Berlin');
});

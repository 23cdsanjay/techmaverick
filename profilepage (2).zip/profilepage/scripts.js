// Sample data for weekly forecast
let weeklyForecast = [
    { day: "Monday", temp: "22°C", condition: "Sunny" },
    { day: "Tuesday", temp: "23°C", condition: "Partly Cloudy" },
    { day: "Wednesday", temp: "24°C", condition: "Cloudy" },
    { day: "Thursday", temp: "21°C", condition: "Rain" },
    { day: "Friday", temp: "20°C", condition: "Sunny" }
];

// Function to display weekly forecast
function displayForecast(forecast) {
    const forecastList = document.getElementById('forecast-list');
    forecastList.innerHTML = '';  // Clear any existing items

    forecast.forEach(day => {
        let item = `<li>
            <strong>${day.day}:</strong> ${day.temp}, ${day.condition}
        </li>`;
        forecastList.innerHTML += item;
    });
}

// Function to fetch and update weather data (simulated)
function fetchWeather() {
    let city = document.getElementById('city-input').value;
    if (city === "") {
        alert("Please enter a city name");
        return;
    }
    
    // Update location and current weather
    document.getElementById('city-name').textContent = city;
    document.getElementById('current-temp').textContent = '23°C';
    document.getElementById('current-weather').textContent = 'Partly Cloudy';

    // Simulated forecast update
    displayForecast(weeklyForecast);
}

// Initialize with default forecast on load
window.onload = function() {
    displayForecast(weeklyForecast);
};

const API_KEY = '876343263193aabb407e773d2f568384'; // Replace with your actual API key

// Fetch weather data based on city name
async function getWeather() {
    const city = document.getElementById('city-input').value.trim();
    if (!city) {
        alert('Please enter a city name.');
        return;
    }
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('City not found');
        }
        const data = await response.json();
        updateWeatherInfo(data);
        updateMap(city);
    } catch (error) {
        alert('Error fetching weather data: ' + error.message);
        console.error(error);
    }
}

// Update weather info on the dashboard
function updateWeatherInfo(data) {
    document.getElementById('city-name').textContent = data.name;
    document.getElementById('temperature').textContent = `${Math.round(data.main.temp)}°C`;
    document.getElementById('condition').textContent = data.weather[0].description;
    
    // Update weather icon based on condition
    const weatherIcon = document.querySelector('.weather-icon');
    weatherIcon.src = getWeatherIcon(data.weather[0].main);
}

// Update the map with the selected city
function updateMap(city) {
    const map = document.getElementById('map').querySelector('iframe');
    map.src = `https://www.google.com/maps?q=${city}&output=embed`;
}

// Get user location and fetch weather based on it
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (position) => {
            const { latitude, longitude } = position.coords;
            const url = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=metric&appid=${API_KEY}`;

            try {
                const response = await fetch(url);
                if (!response.ok) {
                    throw new Error('Unable to fetch location data');
                }
                const data = await response.json();
                updateWeatherInfo(data);
                updateMap(data.name);
            } catch (error) {
                alert('Error fetching weather data: ' + error.message);
                console.error(error);
            }
        }, (error) => {
            alert('Error getting location: ' + error.message);
        });
    } else {
        alert('Geolocation is not supported by this browser.');
    }
}

// Get weather icon based on weather condition
function getWeatherIcon(condition) {
    switch (condition) {
        case "Clouds":
            return "D:/Weather/mavericks/static/clouds.png";
        case "Rain":
            return "D:/Weather/mavericks/static/rain.png";
        case "Clear":
            return "D:/Weather/mavericks/static/clear.png";
        case "Drizzle":
            return "D:/Weather/mavericks/static/drizzle.png";
        case "Mist":
            return "D:/Weather/mavericks/static/mist.png";
        default:
            return "D:/Weather/mavericks/static/clear.png"; // Default icon
    }
}

// Switch between sections
function showSection(sectionId) {
    const sections = document.querySelectorAll('.section');
    sections.forEach((section) => section.classList.remove('active'));
    document.getElementById(sectionId).classList.add('active');
}

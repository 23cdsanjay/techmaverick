// JavaScript for handling the toggling and saving logic

// Sample: Alert when Save Changes button is clicked
document.querySelector('.save-btn').addEventListener('click', function() {
    alert('Your settings have been saved!');
});
